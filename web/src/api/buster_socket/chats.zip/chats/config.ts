export enum FileType {
  DATASET = 'dataset',
  COLLECTION = 'collection',
  METRIC = 'metric',
  DASHBOARD = 'dashboard',
  TERM = 'term',
  VALUE = 'value'
}
