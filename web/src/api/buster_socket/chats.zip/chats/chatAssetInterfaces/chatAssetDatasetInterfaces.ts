export type BusterDatasetAsset = {
  id: string;
};
