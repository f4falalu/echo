export type BusterTermAsset = {
  id: string;
};
