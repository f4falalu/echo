export type BusterCollectionAsset = {
  id: string;
};
