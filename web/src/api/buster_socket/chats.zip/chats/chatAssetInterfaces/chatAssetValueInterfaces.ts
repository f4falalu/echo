export type BusterValueAsset = {
  id: string;
};
